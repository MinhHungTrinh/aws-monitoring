import os
import boto3


ENVIRONMENT = os.getenv("ENVIRONMENT")
PROJECT = os.getenv("PROJECT")

IMPORTANT_TOKEN = os.getenv("IMPORTANT_TOKEN")
IMPORTANT_URL = os.getenv("IMPORTANT_URL")

CICD_TOKEN = os.getenv("CICD_TOKEN")
CICD_URL = os.getenv("CICD_URL")

NORMAL_TOKEN = os.getenv("NORMAL_TOKEN")
NORMAL_URL = os.getenv("NORMAL_URL")

# if not all([IMPORTANT_TOKEN, IMPORTANT_URL, CICD_TOKEN, CICD_URL, NORMAL_TOKEN, NORMAL_URL]):
#   raise ValueError("Missing Environment: IMPORTANT_TOKEN, IMPORTANT_URL, CICD_TOKEN, CICD_URL, NORMAL_TOKEN, NORMAL_URL")\


# client = boto3.client('sts')
# response = client.get_caller_identity()['Account']
