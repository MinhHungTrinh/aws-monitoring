import datetime
import logging
import requests

import settings

logger = logging.getLogger()
logger.setLevel(logging.INFO)


from eventData import (
  EventLevel,
  EventType,
  CodebuildEvent,
  CodepipelineEvent,
  CloudwatchAlarmEvent,
  RDSEvent,
  EC2Event,
  ASGEvent,
  ECSSTaskStateChangeEvent
)


def parse_event(event):
  event_types = {
    "aws.codebuild": CodebuildEvent,
    "aws.cloudwatch": CloudwatchAlarmEvent,
    "aws.autoscaling": ASGEvent,
    "aws.codepipeline": CodepipelineEvent,
    "aws.rds": RDSEvent,
    "aws.ec2": EC2Event,
    "aws.ecs": ECSSTaskStateChangeEvent,
  }
  if event["source"] not in event_types:
    return None

  event_class = event_types[event["source"]]

  event_time = round(datetime.datetime.strptime(event["time"], "%Y-%m-%dT%H:%M:%Sz").timestamp())
  detail_type = event["detail-type"]
  source = event["source"]
  resources = event["resources"]
  region = event["region"]
  account_id = event["account"]

  event_obj = event_class(
    event_time=event_time,
    detail_type=detail_type,
    source=source,
    resources=resources,
    region=region,
    account_id=account_id,
    _event=event,
  )
  return event_obj

def handler(event, context):
  logger.info(event)
  event_data = parse_event(event)
  if event_data is None:
    logger.info("invalid event")
    return

  if event_data.event_level > EventLevel.INFO:
    token = None
    webhook = None
    if event_data.event_type == EventType.CICD:
      token = settings.CICD_TOKEN
      webhook = settings.CICD_URL
    elif event_data.event_type == EventType.NORMAL:
      token = settings.NORMAL_TOKEN
      webhook = settings.NORMAL_URL
    elif event_data.event_type == EventType.IMPORTANT:
      token = settings.IMPORTANT_TOKEN
      webhook = settings.IMPORTANT_URL

    session = requests.Session()

#   Typetalk
#     session.headers.update({
#       "X-TYPETALK-TOKEN": token
#     })
#     rep = session.post(url=webhook, json=event_data.typetalk_event_body())
#   End Typetalk

#   MS Team
    body=event_data.ms_teams_event_body()
    rep = session.post(url=webhook, json=body)
#   End MS Team

    if rep.ok:
      logger.info("Sent notification")
      logger.info(body)
    else:
      logger.error(rep.json())
