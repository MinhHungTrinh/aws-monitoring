import re
import datetime
import settings

from enum import (
    Enum,
    IntEnum
)
from dataclasses import (
    dataclass,
    field
)

class EventType(Enum):
    NORMAL = "NORMAL"
    CICD = "CICD"
    IMPORTANT = "IMPORTANT"

class EventLevel(IntEnum):
    INFO = 0
    NORMAL = 1
    WARNING = 2
    IMPORTANT = 3

@dataclass
class BaseEvent:
    event_time: int
    detail_type: str
    source: str
    resources: list
    region: str
    account_id: str
    notification_url: str = field(init=False)
    notification_icon: str = field(init=False, default="https://cdn.iconscout.com/icon/free/png-256/aws-3215369-2673787.png")
    theme_color: str = field(init=False, default="0076D7")
    _event: dict
    event_type: str = field(init=False)
    event_level: int = field(init=False, default=EventLevel.INFO)

    def __post_init__(self):
        pass

    # need to move to another class
    def event_message(self):
        raise NotImplementedError()
    def typetalk_event_body(self):
        body = {
            "message": (
                            f"{self.event_message()}\n"
                            f'> Account: {self.account_id}\n'
                            f'> Region: {self.region}\n'
                            f'> UTC Time: {self._event["time"]}\n'
                        )
        }
        return body
    def ms_teams_event_body(self):
        body={
                 "@type": "MessageCard",
                 "@context": "http://schema.org/extensions",
                 "themeColor": self.theme_color,
                 "summary": self.event_title(),
                 "sections": [{
                     "activityTitle": self.event_title(),
                     "activitySubtitle": settings.PROJECT + "-" + settings.ENVIRONMENT,
                     "activityImage": self.notification_icon,
                     "facts": [{
                         "name": "Message",
                         "value": self.event_message()
                     }, {
                         "name": "AWS Account",
                         "value": self.account_id
                     }, {
                         "name": "Region",
                         "value": self.region
                     }, {
                         "name": "UTC Time",
                         "value": self._event["time"]
                     }],
                     "markdown": "true"
                 }],
                 "potentialAction": [{
                     "@type": "OpenUri",
                     "name": "Learn More",
                     "targets": [{
                         "os": "default",
                         "uri": self.notification_url
                     }]
                 }]
             }
        return body


class CodebuildEvent(BaseEvent):
    build_status: str = field(init=False)
    project_name: str = field(init=False)
    build_id: str = field(init=False)
    current_phase: str = field(init=False)
    # build_complete: bool = field(init=False)
    # build_start_time: int = field(init=False)
    # phase: list = field(init=False)

    def __post_init__(self):
        self.build_status=self._event["detail"]["build-status"]
        self.project_name=self._event["detail"]["project-name"]
        self.build_id=self._event["detail"]["build-id"]
        self.current_phase=self._event["detail"]["current-phase"]
        # self.build_complete=self._event["detail"]["build-complete"]
        # self.build_start_time=self._event["detail"]["build-start-time"]
        # self.phase=self._event["detail"]["phases"]

        self.event_type = EventType.CICD
        if self.build_status in ["FAILED", "STOPPED"]:
            self.event_level = EventLevel.IMPORTANT

    def event_message(self):
        re_res = re.search("arn:aws:codebuild:(?P<region>[a-z0-9-]+):(?P<account_id>[0-9]+):build/(?P<build_id>[a-zA-Z0-9:-]+)", self.build_id)
        build_url = (
            f'https://{re_res.group("region")}.console.aws.amazon.com/codesuite/'
            f'codebuild/{re_res.group("account_id")}/projects/'
            f'{self.project_name}/build/{re_res.group("build_id")}/?region={re_res.group("region")}'
        )
        self.notification_url = build_url
        message = (
            f'AWS CODEBUILD\n'
            f'[A build of {self.project_name}]({build_url}) {self.build_status}\n'
            f'> Status: {self.build_status}'
        )
        return message

    def event_title(self):
        message = (
            'AWS CODEBUILD'
        )
        return message

class CodepipelineEvent(BaseEvent):
    pipeline: str = field(init=False)
    stage: str = field(init=False)
    state: str = field(init=False) # https://docs.aws.amazon.com/codepipeline/latest/userguide/detect-state-changes-cloudwatch-events.html
    action: str = field(init=False)
    execution_id: str = field(init=False)

    def __post_init__(self):
        self.pipeline = self._event["detail"]["pipeline"]
        self.state = self._event["detail"]["state"]
        self.execution_id = self._event["detail"]["execution-id"]
        if "stage" in self._event["detail"]:
            self.stage = self._event["detail"]["stage"]
        if "action" in self._event["detail"]:
            self.action = self._event["detail"]["action"]
        else:
            self.action = None

        self.event_type = EventType.CICD
        if self.detail_type == "CodePipeline Pipeline Execution State Change":
            self.event_level = EventLevel.IMPORTANT
        elif self.detail_type == "CodePipeline Stage Execution State Change":
            if self.state in ["CANCELED", "FAILED", "STOPPED", "ABANDONED"]:
                self.event_level = EventLevel.IMPORTANT
        elif self.detail_type == "CodePipeline Action Execution State Change":
            if self.state in ["CANCELED", "FAILED", "STOPPED", "ABANDONED"]:
                self.event_level = EventLevel.IMPORTANT
            if self.state in ["STARTED", "SUCCEEDED", "RESUMED"]:
                if self._event["detail"]["type"]["category"] == "Approval":
                    self.event_level = EventLevel.IMPORTANT

    def event_message(self):
        execution_url = (
            f'https://{self.region}.console.aws.amazon.com/codesuite/codepipeline/pipelines/'
            f'{self.pipeline}/executions/{self.execution_id}/'
            f'timeline?region={self.region}'
        )
        self.notification_url = execution_url
        message = (
            "AWS CODEPIPELINE\n"
            f"[Code Pipeline {self.pipeline}]({execution_url}) {self.state}\n"
            f"> State: {self.state}"
        )
        if self.detail_type == "CodePipeline Stage Execution State Change":
            message = (
                f"{message}\n"
                f"> Stage: {self.stage}"
            )
        if self.detail_type == "CodePipeline Action Execution State Change":
            message = (
                f"{message}\n"
                f"> Stage: {self.stage}\n"
                f"> Action: {self.action}"
            )
        return message

    def event_title(self):
        message = (
            'AWS CODEPIPELINE'
        )
        return message

class CloudwatchAlarmEvent(BaseEvent):
    alarm_name: str = field(init=False)
    state: str = field(init=False)
    state_time: int = field(init=False)
    state_reason: str = field(init=False)
    previous_state: str = field(init=False)
    previous_state_time: str = field(init=False)
    previous_state_reason: str = field(init=False)

    def __post_init__(self):
        self.alarm_name = self._event["detail"]["alarmName"]
        self.state = self._event["detail"]["state"]["value"]
        self.state_time = round(datetime.datetime.strptime(
            self._event["detail"]["state"]["timestamp"], "%Y-%m-%dT%H:%M:%S.%f%z"
        ).timestamp())
        self.state_reason = self._event["detail"]["state"]["reason"]
        self.previous_state = self._event["detail"]["previousState"]["value"]
        self.previous_state_time = round(datetime.datetime.strptime(
            self._event["detail"]["previousState"]["timestamp"], "%Y-%m-%dT%H:%M:%S.%f%z"
        ).timestamp())
        self.previous_state_reason = self._event["detail"]["previousState"]["reason"]

        self.event_type = EventType.IMPORTANT
        self.event_level = EventLevel.IMPORTANT
        if self.state == "ALARM":
            self.theme_color = "bf0c06"
        elif self.state == "INSUFFICIENT_DATA":
            self.theme_color = "6e6d6d"


    def event_message(self):
        alarm_url = (
            f'https://{self.region}.console.aws.amazon.com/cloudwatch/home?'
            f'region={self.region}#alarmsV2:alarm/{self.alarm_name}'
        )
        self.notification_url = alarm_url
        message = (
            f'AWS CLOUDWATCH ALARM\n'
            f'[Alarm {self.alarm_name}]({alarm_url}) state change from '
            f'{self.previous_state} to {self.state}\n'
            f'Reason: {self.state_reason}'
        )

        return message

    def event_title(self):
        message = (
            'AWS CLOUDWATCH ALARM'
        )
        return message

class RDSEvent(BaseEvent):
    event_categories: list = field(init=False)
    message: str = field(init=False)
    source_identifier: str = field(init=False)
    event_id: str = field(init=False) # https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_Events.Messages.html

    def __post_init__(self):
        self.event_categories = self._event["detail"]["EventCategories"]
        self.message = self._event["detail"]["Message"]
        self.source_identifier = self._event["detail"]["SourceIdentifier"]
        self.event_id = self._event["detail"]["EventID"]

        if self.detail_type in [ "RDS DB Cluster Event", "RDS DB Instance Event" ]:
            self.event_type = EventType.NORMAL
            self.event_level = EventLevel.NORMAL

    def event_message(self):
        if self.detail_type == "RDS DB Cluster Event":
            return self.event_message_cluster()
        elif self.detail_type == "RDS DB Instance Event":
            return self.event_message_instance()

    def event_message_cluster(self):
        cluster_url = (
            f'https://{self.region}.console.aws.amazon.com/rds/home?region={self.region}#database:id={self.source_identifier};is-cluster=true;tab=connectivity'
        )
        self.notification_url = cluster_url
        message = (
            "AWS RDS CLUSTER\n"
            f'[RDS CLUSTER]({cluster_url})\n'
            f'Message: {self.message}'
        )
        return message

    def event_message_instance(self):
        instance_url = (
            f'https://{self.region}.console.aws.amazon.com/rds/home?region={self.region}#database:id={self.source_identifier};is-cluster=false;tab=connectivity'
        )
        self.notification_url = instance_url
        message = (
            "AWS RDS Instance\n"
            f'[RDS Instance]({instance_url})\n'
            f'Message: {self.message}'
        )
        return message

    def event_title(self):
        message = (
            'AWS RDS Event'
        )
        return message

class EC2Event(BaseEvent):
    instance_id: str = field(init=False)
    state: str = field(init=False) # running, shutting-down, stopped, stopping, terminated

    def __post_init__(self):
        self.instance_id = self._event["detail"]["instance-id"]
        self.state = self._event["detail"]["state"]

        if self.detail_type == "EC2 Instance State-change Notification":
            if self.state in ["stopped", "terminated", "running"]:
                self.event_type = EventType.NORMAL
                self.event_level = EventLevel.NORMAL

    def event_message(self):
        message = (
            "AWS EC2 Instance State Change\n"
            f'> Instance Id: {self.instance_id}\n'
            f'> State: {self.state}'
        )
        return message

    def event_title(self):
        message = (
            'AWS EC2 Event'
        )
        return message

class ASGEvent(BaseEvent):
    asg_name: str = field(init=False)
    instance_id: str = field(init=False)
    status: str = field(init=False)

    def __post_init__(self):
        self.asg_name = self._event["detail"]["AutoScalingGroupName"]
        if self.detail_type in [
            "EC2 Instance Launch Successful", "EC2 Instance Launch Unsuccessful",
            "EC2 Instance Terminate Successful", "EC2 Instance Terminate Unsuccessful"
        ]:
            self.instance_id = self._event["detail"]["EC2InstanceId"]
            self.status = self._event["detail"]["StatusCode"]

            self.event_type = EventType.NORMAL
            self.event_level = EventLevel.NORMAL

    def event_message(self):
        message = (
            "AWS ASG\n"
            f"{self.detail_type}\n"
            f"> ASG: {self.asg_name}"
        )
        return message

    def event_title(self):
        message = (
            'AWS ASG Event'
        )
        return message

class ECSSTaskStateChangeEvent(BaseEvent):
    cluster: str = field(init=False)
    task_definition: str = field(init=False)
    task_id: str = field(init=False)
    last_status: str = field(init=False)
    desired_status: str = field(init=False)


    def __post_init__(self):
        self.cluster = self._event["detail"]["clusterArn"].split(":cluster/")[1]
        self.task_definition = self._event["detail"]["taskDefinitionArn"].split(":task-definition/")[1]
        self.task_id = self._event["detail"]["taskArn"].split(":task/")[1]
        self.last_status = self._event["detail"]["lastStatus"]
        self.desired_status = self._event["detail"]["desiredStatus"]

        if self.last_status == self.desired_status:
            self.event_level = EventLevel.INFO
        else:
            self.event_type = EventType.NORMAL
            self.event_level = EventLevel.NORMAL

    def event_message(self):
        task_url = (
            f'https://{self.region}.console.aws.amazon.com/ecs/home?region={self.region}#/'
            f'clusters/{self.cluster}/tasks/{self.task_id}/details'
        )
        self.notification_url = task_url
        message = (
            "ECS Task State Change\n"
            f"[Task {self.task_definition}]({task_url}) change desired state from "
            f"{self.last_status} to {self.desired_status}\n"
        )
        return message

    def event_title(self):
        message = (
            'AWS ECS Event'
        )
        return message
